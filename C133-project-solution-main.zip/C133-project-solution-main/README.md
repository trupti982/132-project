# -Project-Solution-C133

The folder only has static folder, templates folder and the app.py file. You have to create a virtual environment and install the flask library within.
